# Letese Trading Dashboard

Real-time UI dashboard for monitoring and controlling the Letese Trading Bot.

## 🚀 Features

- **Live Trading Logs**: Real-time monitoring of trading activities
- **Statistics Dashboard**: Comprehensive trading metrics and analytics
- **Control Panel**: Start/Stop/Emergency control for trading bot
- **WebSocket Support**: Real-time updates without page refresh
- **Responsive Design**: Works on desktop and mobile devices
- **Dockerized Deployment**: Easy deployment on any server

## 🏗️ Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Frontend      │     │   Backend API   │     │   Trading Bot   │
│   (Next.js 14)  │◄───►│   (Express.js)  │◄───►│   (Log File)    │
│   Port: 3000    │     │   Port: 3020    │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        │                       │
        │ WebSocket             │ File Watching
        ▼                       ▼
┌─────────────────┐     ┌─────────────────┐
│   Real-time     │     │   Trading Log   │
│   Updates       │     │   Monitoring    │
└─────────────────┘     └─────────────────┘
```

## 📦 Tech Stack

### Frontend
- **Next.js 14** - React framework with App Router
- **TypeScript** - Type safety
- **Tailwind CSS** - Utility-first CSS framework
- **Recharts** - Data visualization
- **React Hot Toast** - Notifications

### Backend
- **Express.js** - REST API server
- **WebSocket** - Real-time communication
- **Chokidar** - File system monitoring
- **Helmet** - Security headers
- **CORS** - Cross-origin resource sharing

### Deployment
- **Docker** - Containerization
- **Docker Compose** - Multi-container orchestration
- **DigitalOcean** - Cloud hosting

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- Docker & Docker Compose
- Git

### Local Development

1. **Clone and navigate to project**
```bash
git clone https://github.com/Gogreenraghav/letese-trading-dashboard.git
cd letese-trading-dashboard
```

2. **Install dependencies**
```bash
npm install
cd backend && npm install
cd ../frontend && npm install
cd ..
```

3. **Start development servers**
```bash
npm run dev
```

4. **Access the dashboard**
- Frontend: http://localhost:3000
- Backend API: http://localhost:3020
- API Documentation: http://localhost:3020/api/status

### Production Deployment

1. **Build and start with Docker**
```bash
docker-compose up -d --build
```

2. **Check running containers**
```bash
docker-compose ps
```

3. **View logs**
```bash
docker-compose logs -f
```

4. **Stop services**
```bash
docker-compose down
```

## 🔧 Configuration

### Environment Variables

#### Backend (.env in backend directory)
```env
PORT=3020
NODE_ENV=production
LOG_FILE_PATH=/root/clawd/universal-trading-bot/trading.log
```

#### Frontend (.env.local in frontend directory)
```env
NEXT_PUBLIC_API_URL=http://localhost:3020
NEXT_PUBLIC_WS_URL=ws://localhost:3020
```

### Port Configuration
- **Frontend**: 3000
- **Backend API**: 3020
- **WebSocket**: 3020 (same as backend)

## 📊 API Endpoints

### GET `/api/status`
Returns current system status
```json
{
  "status": "active",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "server": "DigitalOcean VPS",
  "port": 3020,
  "botConnected": true,
  "exchange": "Binance Testnet"
}
```

### GET `/api/logs`
Returns recent trading logs
```json
{
  "success": true,
  "logs": ["log entry 1", "log entry 2"],
  "total": 1000,
  "timestamp": "2024-01-01T00:00:00.000Z"
}
```

### GET `/api/stats`
Returns trading statistics
```json
{
  "success": true,
  "statistics": {
    "totalLogEntries": 1000,
    "totalTrades": 50,
    "totalErrors": 5,
    "totalWarnings": 10,
    "lastUpdated": "2024-01-01T00:00:00.000Z",
    "uptime": 3600
  }
}
```

### POST `/api/control/start`
Start the trading bot
```json
{
  "success": true,
  "message": "Trading bot started",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "action": "START"
}
```

### POST `/api/control/stop`
Stop the trading bot
```json
{
  "success": true,
  "message": "Trading bot stopped",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "action": "STOP"
}
```

### POST `/api/control/emergency-stop`
Emergency stop the trading bot
```json
{
  "success": true,
  "message": "EMERGENCY STOP activated",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "action": "EMERGENCY_STOP"
}
```

## 🐳 Docker Deployment

### Build Images
```bash
docker-compose build
```

### Start Services
```bash
docker-compose up -d
```

### Monitor Logs
```bash
docker-compose logs -f
```

### Stop Services
```bash
docker-compose down
```

### Update Services
```bash
docker-compose pull
docker-compose up -d --build
```

## 🔒 Security Considerations

1. **API Security**
   - Helmet.js for security headers
   - CORS configuration
   - Rate limiting (to be implemented)

2. **WebSocket Security**
   - Origin validation
   - Connection limits
   - Heartbeat monitoring

3. **File System Security**
   - Read-only access to log files
   - Path validation
   - File size limits

## 📈 Monitoring

### Health Checks
```bash
# Backend health
curl http://localhost:3020/health

# Frontend health
curl http://localhost:3000
```

### Log Monitoring
```bash
# Docker logs
docker-compose logs -f

# Application logs
tail -f /root/clawd/universal-trading-bot/trading.log
```

### Performance Monitoring
- CPU/Memory usage via Docker stats
- API response times
- WebSocket connection count

## 🚨 Troubleshooting

### Common Issues

1. **WebSocket connection failed**
   - Check if backend is running on port 3020
   - Verify firewall settings
   - Check browser console for errors

2. **Log file not found**
   - Verify log file path in backend/.env
   - Check file permissions
   - Ensure trading bot is running

3. **Docker container won't start**
   - Check Docker daemon status
   - Verify port availability
   - Check container logs

### Debug Commands
```bash
# Check container status
docker-compose ps

# View container logs
docker-compose logs [service-name]

# Restart services
docker-compose restart

# Rebuild and restart
docker-compose up -d --build
```

## 🔄 Daily Updates

The repository is updated daily with:
- New features and improvements
- Bug fixes
- Performance optimizations
- Security updates

To update your deployment:
```bash
git pull origin main
docker-compose up -d --build
```

## 📞 Support

For issues and support:
1. Check the troubleshooting section
2. Review application logs
3. Create GitHub issue
4. Contact development team

## 📄 License

MIT License - See LICENSE file for details.

## 🙏 Acknowledgments

- **Next.js Team** for the amazing React framework
- **Express.js Team** for the robust backend framework
- **Docker Team** for containerization technology
- **DigitalOcean** for cloud infrastructure

---

**Version**: 1.0.0  
**Last Updated**: April 7, 2026  
**Maintained By**: Tiwari (AI Assistant)  
**Status**: ✅ PRODUCTION READY