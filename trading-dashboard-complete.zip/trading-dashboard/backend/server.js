const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const { WebSocketServer } = require('ws');
const chokidar = require('chokidar');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3020;

// Middleware
app.use(helmet());
app.use(cors());
app.use(morgan('combined'));
app.use(express.json());

// Path to trading log
const TRADING_LOG_PATH = '/root/clawd/universal-trading-bot/trading.log';

// WebSocket server for real-time updates
const wss = new WebSocketServer({ noServer: true });

// Store connected clients
const clients = new Set();

// Watch trading log file for changes
const watcher = chokidar.watch(TRADING_LOG_PATH, {
  persistent: true,
  ignoreInitial: false
});

// When log file changes, send updates to all connected clients
watcher.on('change', (filePath) => {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n').filter(line => line.trim());
    const lastLines = lines.slice(-50); // Last 50 lines
    
    const update = {
      type: 'LOG_UPDATE',
      timestamp: new Date().toISOString(),
      lines: lastLines,
      totalLines: lines.length
    };
    
    // Send to all connected WebSocket clients
    clients.forEach(client => {
      if (client.readyState === 1) { // OPEN
        client.send(JSON.stringify(update));
      }
    });
  } catch (error) {
    console.error('Error reading log file:', error);
  }
});

// API Routes

// Get current trading status
app.get('/api/status', (req, res) => {
  res.json({
    status: 'active',
    timestamp: new Date().toISOString(),
    server: 'DigitalOcean VPS',
    port: PORT,
    logFile: TRADING_LOG_PATH,
    botConnected: true,
    exchange: 'Binance Testnet'
  });
});

// Get recent trading logs
app.get('/api/logs', (req, res) => {
  try {
    const content = fs.readFileSync(TRADING_LOG_PATH, 'utf8');
    const lines = content.split('\n').filter(line => line.trim());
    const limit = parseInt(req.query.limit) || 100;
    
    res.json({
      success: true,
      logs: lines.slice(-limit),
      total: lines.length,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to read log file',
      message: error.message
    });
  }
});

// Get trading statistics
app.get('/api/stats', (req, res) => {
  try {
    const content = fs.readFileSync(TRADING_LOG_PATH, 'utf8');
    const lines = content.split('\n').filter(line => line.trim());
    
    // Parse trading statistics from logs
    const trades = lines.filter(line => line.includes('TRADE') || line.includes('EXECUTED'));
    const errors = lines.filter(line => line.includes('ERROR') || line.includes('FAILED'));
    const warnings = lines.filter(line => line.includes('WARN') || line.includes('WARNING'));
    
    res.json({
      success: true,
      statistics: {
        totalLogEntries: lines.length,
        totalTrades: trades.length,
        totalErrors: errors.length,
        totalWarnings: warnings.length,
        lastUpdated: new Date().toISOString(),
        uptime: process.uptime()
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to calculate statistics',
      message: error.message
    });
  }
});

// Control endpoints (simulated - would integrate with actual bot control)
app.post('/api/control/start', (req, res) => {
  res.json({
    success: true,
    message: 'Trading bot started',
    timestamp: new Date().toISOString(),
    action: 'START'
  });
});

app.post('/api/control/stop', (req, res) => {
  res.json({
    success: true,
    message: 'Trading bot stopped',
    timestamp: new Date().toISOString(),
    action: 'STOP'
  });
});

app.post('/api/control/emergency-stop', (req, res) => {
  res.json({
    success: true,
    message: 'EMERGENCY STOP activated',
    timestamp: new Date().toISOString(),
    action: 'EMERGENCY_STOP'
  });
});

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage()
  });
});

// Serve frontend in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../frontend/.next')));
  
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/.next/index.html'));
  });
}

// Create HTTP server
const server = app.listen(PORT, () => {
  console.log(`🚀 Trading Dashboard API running on port ${PORT}`);
  console.log(`📊 Monitoring log file: ${TRADING_LOG_PATH}`);
  console.log(`🌐 WebSocket server ready for real-time updates`);
});

// Upgrade HTTP server to support WebSocket
server.on('upgrade', (request, socket, head) => {
  wss.handleUpgrade(request, socket, head, (ws) => {
    wss.emit('connection', ws, request);
  });
});

// WebSocket connection handling
wss.on('connection', (ws) => {
  clients.add(ws);
  console.log(`🔌 New WebSocket client connected. Total clients: ${clients.size}`);
  
  // Send initial data
  try {
    const content = fs.readFileSync(TRADING_LOG_PATH, 'utf8');
    const lines = content.split('\n').filter(line => line.trim());
    
    ws.send(JSON.stringify({
      type: 'INITIAL_DATA',
      timestamp: new Date().toISOString(),
      lines: lines.slice(-100),
      totalLines: lines.length
    }));
  } catch (error) {
    console.error('Error sending initial data:', error);
  }
  
  ws.on('close', () => {
    clients.delete(ws);
    console.log(`🔌 WebSocket client disconnected. Total clients: ${clients.size}`);
  });
  
  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received. Shutting down gracefully...');
  watcher.close();
  wss.close();
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received. Shutting down gracefully...');
  watcher.close();
  wss.close();
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});