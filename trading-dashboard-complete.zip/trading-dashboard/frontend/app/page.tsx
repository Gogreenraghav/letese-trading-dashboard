'use client';

import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { format } from 'date-fns';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import toast from 'react-hot-toast';

// Types
interface LogEntry {
  timestamp: string;
  message: string;
  type: 'INFO' | 'WARNING' | 'ERROR' | 'SUCCESS';
}

interface TradingStats {
  totalLogEntries: number;
  totalTrades: number;
  totalErrors: number;
  totalWarnings: number;
  lastUpdated: string;
  uptime: number;
}

export default function Dashboard() {
  const [logs, setLogs] = useState<string[]>([]);
  const [stats, setStats] = useState<TradingStats | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [activeTab, setActiveTab] = useState<'logs' | 'stats' | 'control'>('logs');

  // Fetch initial data
  const fetchInitialData = useCallback(async () => {
    try {
      const [logsResponse, statsResponse] = await Promise.all([
        axios.get('/api/logs?limit=100'),
        axios.get('/api/stats')
      ]);

      setLogs(logsResponse.data.logs);
      setStats(statsResponse.data.statistics);
      setIsConnected(true);
      
      toast.success('Dashboard connected successfully');
    } catch (error) {
      console.error('Error fetching initial data:', error);
      toast.error('Failed to connect to trading API');
    }
  }, []);

  // Initialize WebSocket connection
  const initWebSocket = useCallback(() => {
    const wsUrl = process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:3020';
    const websocket = new WebSocket(wsUrl);

    websocket.onopen = () => {
      console.log('WebSocket connected');
      setIsConnected(true);
    };

    websocket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === 'LOG_UPDATE') {
          setLogs(prev => [...prev.slice(-199), ...data.lines].slice(-200));
          
          // Update stats if available
          if (stats) {
            setStats(prev => prev ? {
              ...prev,
              totalLogEntries: data.totalLines,
              lastUpdated: new Date().toISOString()
            } : prev);
          }
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    websocket.onerror = (error) => {
      console.error('WebSocket error:', error);
      toast.error('WebSocket connection error');
    };

    websocket.onclose = () => {
      console.log('WebSocket disconnected');
      setIsConnected(false);
      
      // Attempt to reconnect after 5 seconds
      setTimeout(() => {
        initWebSocket();
      }, 5000);
    };

    setWs(websocket);

    return () => {
      websocket.close();
    };
  }, [stats]);

  // Control functions
  const handleStartBot = async () => {
    try {
      await axios.post('/api/control/start');
      toast.success('Trading bot started');
    } catch (error) {
      toast.error('Failed to start trading bot');
    }
  };

  const handleStopBot = async () => {
    try {
      await axios.post('/api/control/stop');
      toast.success('Trading bot stopped');
    } catch (error) {
      toast.error('Failed to stop trading bot');
    }
  };

  const handleEmergencyStop = async () => {
    if (window.confirm('Are you sure you want to perform an emergency stop? This will immediately halt all trading activities.')) {
      try {
        await axios.post('/api/control/emergency-stop');
        toast.success('Emergency stop activated');
      } catch (error) {
        toast.error('Failed to activate emergency stop');
      }
    }
  };

  // Initialize on component mount
  useEffect(() => {
    fetchInitialData();
    const cleanup = initWebSocket();

    return cleanup;
  }, [fetchInitialData, initWebSocket]);

  // Prepare chart data
  const chartData = logs.slice(-20).map((log, index) => ({
    name: `Log ${index + 1}`,
    length: log.length,
  }));

  // Parse log type for styling
  const getLogType = (log: string): LogEntry['type'] => {
    if (log.includes('ERROR') || log.includes('FAILED')) return 'ERROR';
    if (log.includes('WARN') || log.includes('WARNING')) return 'WARNING';
    if (log.includes('SUCCESS') || log.includes('COMPLETED')) return 'SUCCESS';
    return 'INFO';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Status Bar */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className={`flex items-center ${isConnected ? 'text-green-600' : 'text-red-600'}`}>
              <div className={`status-indicator ${isConnected ? 'status-active' : 'status-inactive'}`}></div>
              <span className="ml-2 font-medium">
                {isConnected ? 'Connected' : 'Disconnected'}
              </span>
            </div>
            {stats && (
              <div className="text-sm text-gray-600">
                Uptime: {Math.floor(stats.uptime / 3600)}h {Math.floor((stats.uptime % 3600) / 60)}m
              </div>
            )}
          </div>
          
          <div className="text-sm text-gray-500">
            Last updated: {stats ? format(new Date(stats.lastUpdated), 'HH:mm:ss') : '--:--:--'}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-8">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('logs')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'logs'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Live Logs
            </button>
            <button
              onClick={() => setActiveTab('stats')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'stats'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Statistics
            </button>
            <button
              onClick={() => setActiveTab('control')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'control'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Control Panel
            </button>
          </nav>
        </div>
      </div>

      {/* Tab Content */}
      <div className="fade-in">
        {activeTab === 'logs' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Logs Panel */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow-sm border">
                <div className="px-6 py-4 border-b">
                  <h2 className="text-lg font-medium text-gray-900">Live Trading Logs</h2>
                  <p className="mt-1 text-sm text-gray-500">
                    Real-time updates from trading bot (last 200 entries)
                  </p>
                </div>
                <div className="px-6 py-4">
                  <div className="h-[500px] overflow-y-auto">
                    {logs.length > 0 ? (
                      <div className="space-y-1">
                        {logs.map((log, index) => {
                          const type = getLogType(log);
                          return (
                            <div
                              key={index}
                              className={`log-entry ${type.toLowerCase()} p-3 rounded`}
                            >
                              <div className="flex items-start">
                                <span className="text-xs font-medium px-2 py-1 rounded bg-gray-100 text-gray-800 mr-2">
                                  {type}
                                </span>
                                <code className="text-sm font-mono text-gray-800 flex-1">
                                  {log}
                                </code>
                                <span className="text-xs text-gray-500 ml-2">
                                  {format(new Date(), 'HH:mm:ss')}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        <div className="loading-spinner w-12 h-12 mx-auto mb-4"></div>
                        <p>Loading logs...</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Stats Sidebar */}
            <div>
              <div className="bg-white rounded-lg shadow-sm border">
                <div className="px-6 py-4 border-b">
                  <h2 className="text-lg font-medium text-gray-900">Quick Stats</h2>
                </div>
                <div className="px-6 py-4">
                  {stats ? (
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Total Log Entries</span>
                        <span className="font-bold text-gray-900">{stats.totalLogEntries.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Total Trades</span>
                        <span className="font-bold text-green-600">{stats.totalTrades.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Errors</span>
                        <span className="font-bold text-red-600">{stats.totalErrors.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Warnings</span>
                        <span className="font-bold text-yellow-600">{stats.totalWarnings.toLocaleString()}</span>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <div className="loading-spinner w-8 h-8 mx-auto"></div>
                    </div>
                  )}
                </div>
              </div>

              {/* Chart */}
              <div className="mt-8 bg-white rounded-lg shadow-sm border">
                <div className="px-6 py-4 border-b">
                  <h2 className="text-lg font-medium text-gray-900">Log Activity</h2>
                </div>
                <div className="px-6 py-4">
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="length" stroke="#3b82f6" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'stats' && (
          <div className="bg-white rounded-lg shadow-sm border">
            <div className="px-6 py-4 border-b">
              <h2 className="text-lg font-medium text-gray-900">Detailed Statistics</h2>
            </div>
            <div className="px-6 py-4">
              {stats ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-blue-50 rounded-lg p-6">
                    <div className="text-3xl font-bold text-blue-600">{stats.totalLogEntries.toLocaleString()}</div>
                    <div className="text-sm text-blue-800 mt-2">Total Log Entries</div>
                  </div>
                  <div className="bg-green-50 rounded-lg p-6">
                    <div className="text-3xl font-bold text-green-600">{stats.totalTrades.toLocaleString()}</div>
                    <div className="text-sm text-green-800 mt-2">Total Trades</div>
                  </div>
                  <div className="bg-red-50 rounded-lg p-6">
                    <div className="text-3xl font-bold text-red-600">{stats.totalErrors.toLocaleString()}</div>
                    <div className="text-sm text-red-800 mt-2">Total Errors</div>
                  </div>
                  <div className="bg-yellow-50 rounded-lg p-6">
                    <div className="text-3xl font-bold text-yellow-600">{stats.totalWarnings.toLocaleString()}</div>
                    <div className="text-sm text-yellow-800 mt-2">Total Warnings</div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="loading-spinner w-12 h-12 mx-auto"></div>
                  <p className="mt-4 text-gray-500">Loading statistics...</p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'control' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Control Panel */}
            <div className="bg-white rounded-lg shadow-sm border">
              <div className="px-6 py-4 border-b">
                <h2 className="text-lg font-medium text-gray-900">Bot Control</h2>
                <p className="mt-1 text-sm text-gray-500">
                  Control the trading bot operations
                </p>
              </div>
              <div className="px-6 py-8">
                <div className="space-y-4">
                  <button
                    onClick={handleStartBot}
                    className="w-full btn-primary bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-4 rounded-lg"
                  >
                    Start Trading Bot
                  </button>
                  
                  <button
                    onClick={handleStopBot}
                    className="w-full btn-primary bg-yellow-600 hover:bg-yellow-700 text-white font-medium py-3 px-4 rounded-lg"
                  >
                    Stop Trading Bot
                  </button>
                  
                  <button
                    onClick={handleEmergencyStop}
                    className="w-full btn-danger bg-red-600 hover:bg-red-700 text-white font-medium py-3 px-4 rounded-lg"
                  >
                    Emergency Stop
                  </button>
                </div>
              </div>
            </div>

            {/* System Info */}
            <div className="bg-white rounded-lg shadow-sm border">
              <div className="px-6 py-4 border-b">
                <h2 className="text-lg font-medium text-gray-900">System Information</h2>
              </div>
              <div className="px-6 py-4">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Server</h3>
                    <p className="mt-1 text-gray-900">DigitalOcean VPS (139.59.65.82)</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Port</h3>
                    <p className="mt-1 text-gray-900">3020</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Exchange</h3>
                    <p className="mt-1 text-gray-900">Binance Testnet</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Log File</h3>
                    <p className="mt-1 text-gray-900 font-mono text-sm">
                      /root/clawd/universal-trading-bot/trading.log
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}