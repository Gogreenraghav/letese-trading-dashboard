/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: [],
  },
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: 'http://localhost:3020/api/:path*',
      },
    ];
  },
  env: {
    API_URL: process.env.API_URL || 'http://localhost:3020',
    WS_URL: process.env.WS_URL || 'ws://localhost:3020',
  },
};

module.exports = nextConfig;