#!/bin/bash

# Letese Trading Dashboard - Deployment Script
# Deploy to DigitalOcean VPS (139.59.65.82)

set -e

echo "==========================================="
echo "🚀 Letese Trading Dashboard - Deployment"
echo "==========================================="
echo ""

# Configuration
SERVER_IP="139.59.65.82"
SERVER_USER="root"
DEPLOY_PORT="3020"
PROJECT_DIR="/root/trading-dashboard"
BACKUP_DIR="/root/trading-dashboard-backup"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

# Check if SSH key is available
check_ssh() {
    print_status "Checking SSH connection to $SERVER_IP..."
    if ! ssh -o ConnectTimeout=5 $SERVER_USER@$SERVER_IP "echo 'SSH connection successful'" &>/dev/null; then
        print_error "SSH connection failed to $SERVER_IP"
        print_warning "Please ensure:"
        print_warning "1. Server is running"
        print_warning "2. SSH key is configured"
        print_warning "3. Firewall allows SSH (port 22)"
        exit 1
    fi
    print_status "SSH connection successful"
}

# Backup existing deployment
backup_existing() {
    print_status "Backing up existing deployment..."
    ssh $SERVER_USER@$SERVER_IP "
        if [ -d '$PROJECT_DIR' ]; then
            mkdir -p '$BACKUP_DIR'
            cp -r '$PROJECT_DIR' '$BACKUP_DIR/$(date +%Y%m%d_%H%M%S)'
            print_status 'Backup created successfully'
        else
            print_status 'No existing deployment found'
        fi
    "
}

# Install dependencies on server
install_dependencies() {
    print_status "Installing dependencies on server..."
    ssh $SERVER_USER@$SERVER_IP "
        # Update package list
        apt-get update
        
        # Install Docker if not present
        if ! command -v docker &> /dev/null; then
            print_status 'Installing Docker...'
            apt-get install -y docker.io docker-compose
            systemctl enable docker
            systemctl start docker
        else
            print_status 'Docker already installed'
        fi
        
        # Install Git if not present
        if ! command -v git &> /dev/null; then
            apt-get install -y git
        fi
        
        print_status 'Dependencies installed successfully'
    "
}

# Deploy application
deploy_application() {
    print_status "Deploying application..."
    
    # Create project directory
    ssh $SERVER_USER@$SERVER_IP "mkdir -p '$PROJECT_DIR'"
    
    # Copy project files
    print_status "Copying project files..."
    scp -r ./* $SERVER_USER@$SERVER_IP:$PROJECT_DIR/
    
    # Build and start Docker containers
    print_status "Building and starting Docker containers..."
    ssh $SERVER_USER@$SERVER_IP "
        cd '$PROJECT_DIR'
        
        # Stop existing containers
        docker-compose down 2>/dev/null || true
        
        # Build new images
        docker-compose build
        
        # Start containers
        docker-compose up -d
        
        # Wait for services to start
        sleep 10
        
        # Check if containers are running
        if docker-compose ps | grep -q 'Up'; then
            print_status 'Containers started successfully'
        else
            print_error 'Failed to start containers'
            docker-compose logs
            exit 1
        fi
    "
}

# Configure firewall
configure_firewall() {
    print_status "Configuring firewall..."
    ssh $SERVER_USER@$SERVER_IP "
        # Allow port 3020 (Backend API)
        ufw allow 3020/tcp 2>/dev/null || true
        
        # Allow port 3000 (Frontend)
        ufw allow 3000/tcp 2>/dev/null || true
        
        print_status 'Firewall configured'
    "
}

# Verify deployment
verify_deployment() {
    print_status "Verifying deployment..."
    
    # Check backend health
    print_status "Checking backend health..."
    if curl -s "http://$SERVER_IP:3020/health" | grep -q "healthy"; then
        print_status "Backend is healthy"
    else
        print_error "Backend health check failed"
        return 1
    fi
    
    # Check frontend
    print_status "Checking frontend..."
    if curl -s "http://$SERVER_IP:3000" | grep -q "Letese Trading Dashboard"; then
        print_status "Frontend is running"
    else
        print_error "Frontend check failed"
        return 1
    fi
    
    return 0
}

# Display deployment information
display_info() {
    echo ""
    echo "==========================================="
    echo "🎉 DEPLOYMENT SUCCESSFUL!"
    echo "==========================================="
    echo ""
    echo "📊 Application URLs:"
    echo "   Frontend Dashboard:  http://$SERVER_IP:3000"
    echo "   Backend API:         http://$SERVER_IP:3020"
    echo "   API Status:          http://$SERVER_IP:3020/api/status"
    echo ""
    echo "🔧 Management Commands:"
    echo "   View logs:           ssh $SERVER_USER@$SERVER_IP 'cd $PROJECT_DIR && docker-compose logs -f'"
    echo "   Restart services:    ssh $SERVER_USER@$SERVER_IP 'cd $PROJECT_DIR && docker-compose restart'"
    echo "   Stop services:       ssh $SERVER_USER@$SERVER_IP 'cd $PROJECT_DIR && docker-compose down'"
    echo "   Update deployment:   Run this script again"
    echo ""
    echo "📈 Monitoring:"
    echo "   Check health:        curl http://$SERVER_IP:3020/health"
    echo "   View container stats: ssh $SERVER_USER@$SERVER_IP 'docker stats'"
    echo ""
    echo "⚠️  Important Notes:"
    echo "   1. Ensure trading bot log file exists: /root/clawd/universal-trading-bot/trading.log"
    echo "   2. The dashboard monitors this log file in real-time"
    echo "   3. Control buttons will need integration with actual bot control system"
    echo ""
    echo "==========================================="
}

# Main deployment process
main() {
    echo "Starting deployment to DigitalOcean VPS ($SERVER_IP)"
    echo ""
    
    # Check prerequisites
    check_ssh
    
    # Backup existing deployment
    backup_existing
    
    # Install dependencies
    install_dependencies
    
    # Deploy application
    deploy_application
    
    # Configure firewall
    configure_firewall
    
    # Verify deployment
    if verify_deployment; then
        display_info
    else
        print_error "Deployment verification failed"
        print_warning "Check logs: ssh $SERVER_USER@$SERVER_IP 'cd $PROJECT_DIR && docker-compose logs'"
        exit 1
    fi
}

# Run main function
main "$@"